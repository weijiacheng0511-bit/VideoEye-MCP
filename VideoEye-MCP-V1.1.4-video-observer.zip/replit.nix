{ pkgs }: {
  deps = [
    pkgs.ffmpeg
  ];
}
