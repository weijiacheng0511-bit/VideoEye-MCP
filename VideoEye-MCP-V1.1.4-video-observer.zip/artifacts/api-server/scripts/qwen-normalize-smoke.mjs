import { registerHooks } from "node:module";
import path from "node:path";

registerHooks({
  resolve(specifier, context, nextResolve) {
    return nextResolve(specifier.startsWith(".") && !path.extname(specifier) && context.parentURL?.includes("/src/videoeye/") ? `${specifier}.ts` : specifier, context);
  },
});

const { normalizeQwenProviderResult } = await import("../src/videoeye/qwen-worker.ts");

const missing = normalizeQwenProviderResult({ answer: "主体分析已经存在" }, '{"answer":"主体分析已经存在"}');
if (missing.result.answer !== "主体分析已经存在") throw new Error("answer fallback failed");
if (missing.result.summary !== "") throw new Error("summary default failed");
if (missing.result.important_events.length !== 0) throw new Error("important_events default failed");
if (!missing.warnings.includes("summary_missing_defaulted")) throw new Error("missing-field warning absent");

const aliased = normalizeQwenProviderResult({ analysis: {
  answer: "ok",
  overview: "overview text",
  key_events: [{ timestamp: "00:03", event: "event", evidence: "visual" }],
  visual_summary: "visual text",
  dialogue_summary: "speech text",
} });
if (aliased.result.summary !== "overview text") throw new Error("summary alias failed");
if (aliased.result.important_events[0]?.event !== "event") throw new Error("events alias failed");
if (aliased.result.visual_description !== "visual text") throw new Error("visual alias failed");
if (aliased.result.spoken_content_summary !== "speech text") throw new Error("speech alias failed");

console.log(JSON.stringify({
  ok: true,
  missing_field_fallback: missing,
  alias_normalization: aliased.result,
}, null, 2));
