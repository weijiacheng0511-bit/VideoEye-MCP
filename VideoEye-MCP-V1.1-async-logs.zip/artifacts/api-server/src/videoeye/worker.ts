export interface AnalyzeRequest {
  videoId: string;
  videoPath: string;
  question: string;
  startTime?: number;
  endTime?: number;
  previousContext?: unknown;
  onProgress?: (stage: "provider_upload" | "provider_inference" | "finalize") => void | Promise<void>;
}

export interface VideoObservation {
  answer: string;
  observations: string[];
  timestamps: number[];
  provider: string;
  summary?: string;
  important_events?: { timestamp: string; event: string }[];
  visual_description?: string;
  spoken_content_summary?: string;
  model?: string;
  file_state?: string | null;
  gemini_file_name?: string | null;
}

export interface VideoWorker {
  analyze(request: AnalyzeRequest): Promise<VideoObservation>;
}

export class MockVideoWorker implements VideoWorker {
  calls: AnalyzeRequest[] = [];
  async analyze(request: AnalyzeRequest): Promise<VideoObservation> {
    this.calls.push(request);
    await request.onProgress?.("provider_upload");
    await request.onProgress?.("provider_inference");
    await request.onProgress?.("finalize");
    return {
      answer: "MockVideoWorker 测试数据；未实际观察视频。",
      observations: ["MockVideoWorker 已收到视频路径和问题；无视频事实观察。"],
      timestamps: [], provider: "mock",
    };
  }
}
