import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { z } from "zod";
import type { AnalyzeRequest, VideoObservation, VideoWorker } from "./worker";

export const QWEN_VIDEO_MODEL = "qwen3.8-omni-flash";

const resultSchema = z.object({
  answer: z.string(),
  summary: z.string(),
  important_events: z.array(z.object({
    timestamp: z.string(), event: z.string(), evidence: z.enum(["audio", "visual", "both"]),
  })),
  visual_description: z.string(),
  spoken_content_summary: z.string(),
  screen_text: z.array(z.string()).default([]),
  visual_only_information: z.array(z.string()).default([]),
  people_actions: z.array(z.string()).default([]),
  uncertain_points: z.array(z.string()).default([]),
});

type QwenResult = z.infer<typeof resultSchema>;
export interface QwenUsage {
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  prompt_tokens_details?: unknown;
  completion_tokens_details?: unknown;
}
export type QwenObservation = VideoObservation & QwenResult & {
  usage: QwenUsage | null;
  elapsed_ms: number;
  video_bytes: number;
  input_method: "complete_mp4_oss_video_url";
};

const hosts: Record<string, string> = {
  "cn-beijing": "dashscope.aliyuncs.com",
  "ap-southeast-1": "dashscope-intl.aliyuncs.com",
};

function endpoint(): string {
  const region = process.env.DASHSCOPE_REGION ?? "cn-beijing";
  const host = hosts[region];
  if (!host) throw new Error("DASHSCOPE_REGION 必须为 cn-beijing 或 ap-southeast-1");
  return `https://${host}`;
}

function safeError(message: string, key: string): string {
  return message.replaceAll(key, "[REDACTED]").slice(0, 600);
}

async function checkedResponse(response: Response, action: string, key: string): Promise<void> {
  if (response.ok) return;
  let detail = "";
  try {
    const body = await response.json() as { code?: string; message?: string };
    detail = ` ${String(body.code ?? "")} ${String(body.message ?? "")}`;
  } catch { /* The status still identifies the failing stage. */ }
  throw new Error(safeError(`${action} HTTP ${response.status}${detail}`, key));
}

async function uploadMp4(videoPath: string, apiKey: string, base: string): Promise<string> {
  const policyUrl = new URL("/api/v1/uploads", base);
  policyUrl.searchParams.set("action", "getPolicy");
  policyUrl.searchParams.set("model", QWEN_VIDEO_MODEL);
  const policyResponse = await fetch(policyUrl, {
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    signal: AbortSignal.timeout(60000),
  });
  await checkedResponse(policyResponse, "百炼上传凭证", apiKey);
  const payload = await policyResponse.json() as { data?: Record<string, string> };
  const policy = payload.data;
  if (!policy || !policy.upload_host || !policy.upload_dir || !policy.policy || !policy.signature || !policy.oss_access_key_id) {
    throw new Error("百炼上传凭证缺少必要字段");
  }
  const uploadHost = new URL(policy.upload_host);
  if (uploadHost.protocol !== "https:" || !uploadHost.hostname.endsWith(".aliyuncs.com") ||
      uploadHost.username || uploadHost.password || uploadHost.port) throw new Error("百炼上传地址无效");
  const fileName = path.basename(videoPath);
  const objectKey = `${policy.upload_dir}/${fileName}`;
  const bytes = await readFile(videoPath);
  if (bytes.length < 12 || bytes.toString("ascii", 4, 8) !== "ftyp") throw new Error("上传文件不是完整 MP4 容器");
  const form = new FormData();
  form.append("OSSAccessKeyId", policy.oss_access_key_id);
  form.append("Signature", policy.signature);
  form.append("policy", policy.policy);
  form.append("x-oss-object-acl", policy.x_oss_object_acl ?? "private");
  form.append("x-oss-forbid-overwrite", policy.x_oss_forbid_overwrite ?? "true");
  form.append("key", objectKey);
  form.append("success_action_status", "200");
  form.append("file", new Blob([bytes], { type: "video/mp4" }), fileName);
  const uploadResponse = await fetch(uploadHost, {
    method: "POST", body: form, signal: AbortSignal.timeout(300000),
  });
  await checkedResponse(uploadResponse, "百炼临时 MP4 上传", apiKey);
  return `oss://${objectKey}`;
}

async function readCompletion(response: Response): Promise<{ content: string; usage: QwenUsage | null }> {
  if (!response.body) throw new Error("百炼未返回响应体");
  let buffer = "";
  let content = "";
  let usage: QwenUsage | null = null;
  const decoder = new TextDecoder();
  const consume = (event: string) => {
    const data = event.split("\n").filter(line => line.startsWith("data:")).map(line => line.slice(5).trimStart()).join("\n");
    if (!data || data === "[DONE]") return;
    const chunk = JSON.parse(data) as {
      choices?: { delta?: { content?: string | null } }[];
      usage?: QwenUsage | null;
      error?: { message?: string };
    };
    if (chunk.error) throw new Error(`百炼流式响应失败：${chunk.error.message ?? "unknown"}`);
    content += chunk.choices?.[0]?.delta?.content ?? "";
    if (chunk.usage) usage = chunk.usage;
  };
  for await (const part of response.body) {
    buffer = (buffer + decoder.decode(part, { stream: true })).replaceAll("\r\n", "\n");
    let end: number;
    while ((end = buffer.indexOf("\n\n")) !== -1) {
      consume(buffer.slice(0, end));
      buffer = buffer.slice(end + 2);
    }
  }
  buffer += decoder.decode();
  if (buffer.trim()) consume(buffer);
  return { content, usage };
}

function seconds(timestamp: string): number | null {
  const parts = timestamp.split("-")[0].trim().split(":").map(Number);
  if ((parts.length !== 2 && parts.length !== 3) || parts.some(n => !Number.isFinite(n) || n < 0)) return null;
  return parts.reduce((total, n) => total * 60 + n, 0);
}

export class QwenVideoWorker implements VideoWorker {
  readonly model = QWEN_VIDEO_MODEL;
  uploaded = false;

  async analyze(request: AnalyzeRequest): Promise<QwenObservation> {
    const started = performance.now();
    const apiKey = process.env.DASHSCOPE_API_KEY;
    if (!apiKey || apiKey.includes("<把你的百炼 Key 粘在这里>")) {
      throw new Error("等待 API Key：请在当前运行环境设置真实的 DASHSCOPE_API_KEY");
    }
    const file = await stat(request.videoPath);
    if (!file.isFile() || file.size < 12) throw new Error("缓存 MP4 不存在或为空");
    const base = endpoint();
    await request.onProgress?.("provider_upload");
    const videoUrl = await uploadMp4(request.videoPath, apiKey, base);
    this.uploaded = true;
    await request.onProgress?.("provider_inference");

    const focus = request.startTime === undefined && request.endTime === undefined ? "" :
      `重点回答 ${request.startTime ?? 0} 至 ${request.endTime ?? "视频结尾"} 秒，仍须观看完整视频。`;
    const previous = request.previousContext === undefined ? "" :
      `此前对话背景：${JSON.stringify(request.previousContext)}。`;
    const prompt = `请完整观看所附原始 MP4，同时理解画面与内嵌音频。不要仅概括口播。` +
      `逐项关注主讲人所说内容、UI、动画、图表、屏幕文字、画面独有信息、人物动作和明显视觉变化。` +
      `只根据视频说事实，不要依据标题猜测；区分视频中可观察事实、主讲人观点和无法确认的推测。` +
      `重要事件给出视频内时间戳，无法确认的时间戳不要编造。${focus}${previous}` +
      `视频 ID：${request.videoId}。用户问题：${request.question}。` +
      `请返回 JSON 对象，包含 answer、summary、important_events（每项 timestamp、event、evidence，evidence 只能是 audio、visual 或 both）、` +
      `visual_description、spoken_content_summary、screen_text、visual_only_information、people_actions、uncertain_points。`;
    const response = await fetch(new URL("/compatible-mode/v1/chat/completions", base), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "X-DashScope-OssResourceResolve": "enable",
      },
      body: JSON.stringify({
        model: this.model,
        messages: [{ role: "user", content: [
          { type: "video_url", video_url: { url: videoUrl } },
          { type: "text", text: prompt },
        ] }],
        modalities: ["text"],
        reasoning_effort: "none",
        response_format: { type: "json_object" },
        stream: true,
        stream_options: { include_usage: true },
      }),
      signal: AbortSignal.timeout(900000),
    });
    await checkedResponse(response, "百炼视频分析", apiKey);
    const { content, usage } = await readCompletion(response);
    await request.onProgress?.("finalize");
    if (!content) throw new Error("百炼没有返回视频分析文本");
    let result: QwenResult;
    try { result = resultSchema.parse(JSON.parse(content)); }
    catch (error) {
      const reason = error instanceof z.ZodError ? JSON.stringify(error.issues) :
        error instanceof Error ? error.message : String(error);
      throw new Error(`百炼结果解析失败：${reason.slice(0, 800)}`);
    }
    return {
      ...result,
      observations: result.important_events.map(item => `${item.timestamp} [${item.evidence}] ${item.event}`),
      timestamps: result.important_events.map(item => seconds(item.timestamp)).filter((n): n is number => n !== null),
      provider: "qwen", model: this.model, usage,
      elapsed_ms: Math.round(performance.now() - started),
      video_bytes: file.size, input_method: "complete_mp4_oss_video_url",
    };
  }
}
